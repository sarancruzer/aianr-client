# Contributing

1. Check if the feature or bug exists in `Issues`.
1. If not, put an `issue`.If you wanna work on it, please let us know.
1. `fork` this repository.
1. Clone your own repository and make your changes.
1. Commit your changes with a short message and push to your repository.
1. Send a `Pull Request`.
