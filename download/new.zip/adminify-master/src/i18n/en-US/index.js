export default {
  'Search': 'Search',
  'Create ': 'Create ',
  'Submit': 'Submit',
  'Edit': 'Edit',
  'Close': 'Close',
  'Field should be unique.': 'Field should be unique.'
}
