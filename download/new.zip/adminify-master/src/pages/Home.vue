<template lang="pug">
.text-center
  v-card
    v-card-text Slient is Gold ?
</template>

<script>
export default {
  data () {
    return {}
  },

  mounted () {
  }
}
</script>
